/**
 * 
 */
/**
 * @author User
 *
 */
module MYLIB {
}