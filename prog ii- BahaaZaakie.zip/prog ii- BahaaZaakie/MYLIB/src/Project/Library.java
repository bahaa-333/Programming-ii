package Project;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Library {
	static ArrayList<Book> Collection = new ArrayList<Book>();
	
	public Library() {
	
	}
	
	public void AddBook(Book book) {
		Collection.add(book);
	}
	
	public void DelBook(String titl) {
		if(Collection.isEmpty()) {
			System.out.println("You need to add Books to your Library first!");
		}
		else {
			int flag = -1;
			for(int i = 0 ; i < Collection.size() ; i++) {
				if(titl.equalsIgnoreCase(Collection.get(i).Gettitle())) {
					flag = i;
					break;
				}
				
			}
			
			if(flag == -1) {
				System.out.println("Couldn't find " + titl+ "in directory.");
			}
			else {
				Book toremove = Collection.get(flag);
				Collection.remove(flag);
				System.out.println(toremove + " has been removed from directory.");
				toremove = null;
			}
		}
	}
	
	public Book Searchbook(String titl) {
		if(Collection.isEmpty()) {
			System.out.println("You need to add Books to your Library first!");
		}
		else {
			int flag = -1;
			for(int i = 0 ; i < Collection.size() ; i++) {
				if(titl.equalsIgnoreCase(Collection.get(i).Gettitle())) {
					flag = i;
					break;
				}
				
			}
			
			if(flag == -1) {
				System.out.println("Couldn't find " + titl+ "in directory.");
			}
			else {
				return Collection.get(flag);
				}
			}
		return null;
	}
	
	public void exportToCSV(String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            // Write header
            writer.write("Title,Author,Genre,Year,ISBN,Rating\n");

            // Write each book's data
            for (Book book : Collection) {
                writer.write(
                        String.format("%s,%s,%s,%d,%d,%i\n",
                                book.Gettitle(),
                                book.Getauthor(),
                                book.Getgenre(),
                                book.Getyear(),
                                book.Getisbn(),
                                book.Getrating()
                        )
                );
            }

            System.out.println("Data exported successfully to " + filename);
        } catch (IOException e) {
            System.out.println("An error occurred while exporting data to CSV: " + e.getMessage());
        }
    }
	
	
	public ArrayList<Book> GetCollection(){
		return Collection;
	}
	
	public String ToString() {
		String fin = "List of Books: \n";
		for(Book bk:Collection)
			fin += bk;
		return fin;
		
	}
}
