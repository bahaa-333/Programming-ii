package Project;

import java.text.NumberFormat;
import java.util.ArrayList;

public class Listing extends Library{
	private double total = 0.0;
	
	NumberFormat money = NumberFormat.getCurrencyInstance();
	
	ArrayList<Book> lot = new ArrayList<Book>();
	@Override
	public ArrayList<Book> GetCollection() {
		return lot ;
	}
	
	public Listing() {
		
	}
	
	public double Gettot() {
		for(int i = 0; i < lot.size() ; i++) {
			total += lot.get(i).Getprice();
		}
		return total;
	}
	
	public String ToString() {
		String res = new String();
		for(Book em:lot)
		res += em;
		return res + "Number of Books: " + lot.size() +"\nTotal value: " + total;
	}
}
