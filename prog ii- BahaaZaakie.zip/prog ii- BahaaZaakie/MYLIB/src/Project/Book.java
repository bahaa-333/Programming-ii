package Project;

import java.text.*;

public class Book {
	private String title;
	private Author author;
	private int year;
	private float isbn;
	private String genre;
	private double price;
	private double rating;
	private String publisher;
	
	NumberFormat money = NumberFormat.getCurrencyInstance();
	
	public Book(String title, Author author, int year, float isbn, String genre, double price, double rating, String publisher){
		this.title = title;
		this.author = author;
		
		if(year>=0 && year<=2026) {
			this.year = year;
		}
		else {
			this.year = 2000;
		}
		
		this.year = year;
		if(isbn/Math.pow(10,13) == 0) {
			this.isbn = isbn;
		}
		else {
			this.isbn = 0000000000000;
		}
		if(genre.toLowerCase() == "romance" || genre.toLowerCase() == "biography" || genre.toLowerCase() == "selfhelp") {
			this.genre = genre;
		}
		else {
			this.genre = "N/A";
		}
		this.price = price;
		
		if(rating>=0 && rating<=5) {
			this.rating = rating;
		}
		else {
			this.rating = 0;
		}
		
		this.publisher = publisher;
	}
	
	

	public void Settitle(String title) {
		this.title = title;
	}
	
	public void Setauthor(Author author) {
		this.author = author;
	}
	
	public void Setyear(int year) {
		if(year>=0 && year<=2026) {
			this.year = year;
		}
		else {
			this.year = 2000;
		}
	}
	
	public void Setisbn(float isbn) {
		if(isbn/Math.pow(10,13) == 0) {
			this.isbn = isbn;
		}
		else {
			this.isbn = 0000000000000;
		}
	}
	
	public void Setgenre(String genre) {
		if(genre.toLowerCase() == "romance" || genre.toLowerCase() == "biography" || genre.toLowerCase() == "selfhelp") {
			this.genre = genre;
		}
		else {
			this.genre = "N/A";
		}
	}
	
	public void Setprice(double price) {
		this.price = price;
	}
	
	public void Setrating(double rating) {
		if(rating>=0 && rating<=5) {
			this.rating = rating;
		}
		else {
			this.rating = 0;
		}
	}
	
	public void Setpublisher(String publisher) {
		this.publisher = publisher;
	}
	
	
	public String Gettitle() {
		return this.title;
	}
	
	public Author Getauthor() {
		return this.author;
	}
	
	public String Getpublisher() {
		return this.publisher;
	}
	
	public int Getyear() {
		return this.year;
	}
	
	public float Getisbn() {
		return this.isbn;
	}
	public String Getgenre() {
		return this.genre;
	}
	
	public double Getprice() {
		return this.price;
	}
	
	public double Getrating() {
		return this.rating;
	}
	
	public String ToString() {
		return title + ":\n" + "Author: "+ author + "\n Year: " + year + "Publisher: " + publisher + "\n Rating:" + rating + "/5" + "\n Price: " + money.format(price) + "\n ISBN: " + isbn;
	}

	
	
}
