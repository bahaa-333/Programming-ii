package Project;

public abstract class Author {
	private String firstname;
	private String lastname;
	private String gender;
	
	public Author(String fname, String lname, String gender) {
		this.firstname = fname;
		this.lastname = lname;
		
		if(gender.toLowerCase() == "male" || gender.toLowerCase() == "female") {
			this.gender = gender;
		}
		else {
			this.gender = "N/A";
		}
	}
	
	public void Setfname(String fname) {
		this.firstname = fname;
	}
	
	public void Setlname(String lname) {
		this.lastname = lname;
	}
	
	public void Setgen(String gender) {
		if(gender.toLowerCase() == "male" || gender.toLowerCase() == "female") {
			this.gender = gender;
		}
		else {
			this.gender = "N/A";
		}
	}
	
	public String Getfname() {
		return this.firstname;
	}
	
	public String Getlname() {
		return this.lastname;
	}
	
	public String GetGender() {
		return this.gender;
	}
	
	public String ToString() {
		return "AUTHOR:\n" + this.firstname + " " + this.lastname + "\n" + "Gender: " + this.gender;
	}
	
}
