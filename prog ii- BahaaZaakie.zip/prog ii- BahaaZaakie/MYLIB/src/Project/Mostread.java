package Project;

import java.util.ArrayList;

public class Mostread extends Library{
	ArrayList<Book> lot = new ArrayList<Book>();
	@Override
	public ArrayList<Book> GetCollection() {
		return lot ;
	}
	private int countsel = 0;
	private int countrom = 0;
	private int countbio = 0;
	
	public int getCountsel() {
		return countsel;
	}

	public void setCountsel(int countsel) {
		this.countsel = 0;
	}

	public int getCountrom() {
		return countrom;
	}

	public void setCountrom(int countrom) {
		this.countrom =0;
	}

	public int getCountbio() {
		return countbio;
	}

	public void setCountbio(int countbio) {
		this.countbio = 0;
	
	
	for(int i = 0 ; i < lot.size() ; i++) {
		if(lot.get(i).Getgenre().toLowerCase()=="romance") {
			setCountrom(getCountrom() + 1);
		}
		else if(lot.get(i).Getgenre().toLowerCase()=="biography") {
			setCountbio(getCountbio() + 1);
		}
		else if(lot.get(i).Getgenre().toLowerCase()=="selfhelp") 
			setCountsel(getCountsel() + 1);
		}
}
		
	
	
	public String ToString() {
		return "Number of romance books: "+countrom+"\n Number of autobiographies: "+countbio+"\n Number of selfhelp books: "+countsel;
	}

}