package Project;

import java.util.Scanner;

public class mylibsis {
	public static void main(String[] args) {
		Library myLibrary = new Library();
		Scanner s = new Scanner(System.in);
		int choice = 0;
		
		
		 do {
	            System.out.println("\nLibrary Management System Menu:");
	            System.out.println("1. Add Book");
	            System.out.println("2. Remove Book");
	            System.out.println("3. Search Book");
	            System.out.println("4. Display All Books");
	            System.out.println("5. Edit Book");
	            System.out.println("6. List Books with Lib value");
	            System.out.println("7. Display genres");
	            System.out.println("8. Export Library to CSV");
	            System.out.println("9. Exit");
	            System.out.print("Enter your choice: ");
	            choice = s.nextInt();
	            
		 switch (choice) {
         case 1:
             System.out.println("Enter Book details:");
             s.nextLine(); 
             System.out.print("Title: ");
             String title = s.nextLine();
             
             System.out.println("Enter Author details:");
             System.out.print("First Name: ");
             String firstName = s.nextLine();
             System.out.print("Last Name: ");
             String lastName = s.nextLine();
             System.out.print("Gender: ");
             String gender = s.nextLine();
             
             Author author = new Author(firstName, lastName, gender);
             
             System.out.print("Year: ");
             int year = s.nextInt();
             System.out.print("ISBN: ");
             float isbn = s.nextFloat();
             s.nextLine(); 
             System.out.print("Genre: ");
             String genre = s.nextLine();
             System.out.print("Price: ");
             double price = s.nextDouble();
             System.out.print("Rating: ");
             double rating = s.nextDouble();
             s.nextLine();
             System.out.print("Publisher: ");
             String publisher = s.nextLine();
             
             Book book = new Book(title, author, year, isbn, genre, price, rating, publisher);
             myLibrary.AddBook(book);
             break;
         case 2:
             System.out.print("Enter title of the book to remove: ");
             s.nextLine();
             String titleToRemove = s.nextLine();
             myLibrary.DelBook(titleToRemove);
             break;
         case 3:
             System.out.print("Enter title of the book to search: ");
             s.nextLine(); 
             String titleToSearch = s.nextLine();
             Book foundBook = myLibrary.Searchbook(titleToSearch);
             if (foundBook != null) {
                 System.out.println("Book Found: " + foundBook);
             }
             break;
         case 4:
             System.out.println(myLibrary);
             break;
         case 5:
        	 System.out.print("Enter title of the book to edit: ");
        	    s.nextLine(); 
        	    String titleToEdit = s.nextLine();
        	    Book bookToEdit = myLibrary.Searchbook(titleToEdit);
        	    if (bookToEdit != null) {
        	        System.out.println("Book Found: " + bookToEdit);
        	        System.out.println("Enter new details for the book:");
        	        
        	        System.out.print("New Title: ");
        	        String newTitle = s.nextLine();
        	        
        	        System.out.println("Enter new Author details:");
        	        System.out.print("First Name: ");
        	        String newFirstName = s.nextLine();
        	        System.out.print("Last Name: ");
        	        String newLastName = s.nextLine();
        	        System.out.print("Gender: ");
        	        String newGender = s.nextLine();
        	        Author newAuthor = new Author(newFirstName, newLastName, newGender);
        	        
        	        System.out.print("New Year: ");
        	        int newYear = s.nextInt();
        	        System.out.print("New ISBN: ");
        	        float newIsbn = s.nextFloat();
        	        s.nextLine();
        	        System.out.print("New Genre: ");
        	        String newGenre = s.nextLine();
        	        System.out.print("New Price: ");
        	        double newPrice = s.nextDouble();
        	        System.out.print("New Rating: ");
        	        double newRating = s.nextDouble();
        	       s.nextLine();
        	        System.out.print("New Publisher: ");
        	        String newPublisher = s.nextLine();
        	        
        	        bookToEdit.Settitle(newTitle);
        	        bookToEdit.Setauthor(newAuthor);
        	        bookToEdit.Setyear(newYear);
        	        bookToEdit.Setisbn(newIsbn);
        	        bookToEdit.Setgenre(newGenre);
        	        bookToEdit.Setprice(newPrice);
        	        bookToEdit.Setrating(newRating);
        	        bookToEdit.Setpublisher(newPublisher);
        	        
        	        System.out.println("Book details updated successfully!");
        	    } else {
        	        System.out.println("Book with title " + titleToEdit + " not found.");
        	    }
        	    break;
         case 6:
        	 System.out.println(Listing);
             break;
         case 7:
        	 System.out.println(mostRead);
             break;
         case 8:
             System.out.print("Enter CSV file name to export: ");
             s.nextLine(); 
             String filename = s.nextLine();
             myLibrary.exportToCSV("library_data.csv");
             break;
         case 9:
              System.out.println("Exiting...");
             break;
         default:
             System.out.println("Invalid choice. Please enter a number between 1 and 6.");
     
 } while (choice != 9);

 s.close();	

		 }
	}
		 
	
}
